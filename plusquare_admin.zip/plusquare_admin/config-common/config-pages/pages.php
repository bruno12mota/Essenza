<?php

//Gallery
require_once( 'gallery_admin.php' );

//Page
require_once( 'pages_admin.php' );

//Portfolio
require_once( 'portfolio_admin.php' );

//Posts
require_once( 'posts_admin.php' );

//Slider
require_once( 'slider_admin.php' );

//Slider
require_once( 'sidebar.php' );