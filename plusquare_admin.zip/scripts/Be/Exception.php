<?php

class Be_Exception extends Exception {}